// 给所有的图片加上点击事件
function img_click(obj) {
	window.open(obj.src);
}