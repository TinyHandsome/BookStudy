#!/usr/bin/env python
# -*- coding: UTF-8 -*-
# coding=utf-8 

"""
@author: Liyingjun
@contact: 694317828@qq.com
@software: pycharm
@file: utils_views.py
@time: 2022/4/11 9:18
@desc: 各种工具，比如装饰器
"""


def post_params_check():
    """post数据检查"""
